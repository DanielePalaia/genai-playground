"""
GenAI Playground - Experiments with LangChain and LangGraph
"""

__version__ = "0.1.0" 